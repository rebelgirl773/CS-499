# CS-499 Capstone
This is a CS-499 Computer Science Capstone 2024 course that demonstrates the skills learned in the SNHU Bachelor of Science degree. The course requires you to find an artifact in previous work. I chose to work in CS-465 Full Stack Development since the course was recently reworked, and the instructions were incomplete to make a working website and admin site. So, I decided to fix the Full Stack code to fulfill my requirements for the CS-499 course.

In the CS-465 the goal is to make a basic traveling agency website to book trips. The code here in travlr_enhanced is the final code from the CS-499 course fixing the Full stack code, and the travlr_original is the original code before fixes were made. The code in those folders goes into the C:\Users\username\travlr folder
