const contact = (req, res) => {
    res.render('contact', {title: 'Contact',contactPage:true});
  };
  
  module.exports = {
    contact
  };




