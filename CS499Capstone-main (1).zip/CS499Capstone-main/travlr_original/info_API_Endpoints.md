| HTTP Method | Purpose                   | URL                | Relevant Notes                             |
|-------------|---------------------------|--------------------|--------------------------------------------|
| GET         | List all Trips            | /trip         |                                            |
| GET         | Retrieve a single trip by code          | /trips/:tripCode         | Returns a single trip object from the database by trip code       |
| 
